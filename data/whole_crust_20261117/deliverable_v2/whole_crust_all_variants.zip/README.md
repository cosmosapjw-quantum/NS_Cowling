# Whole-crust A: portable EOS bundle

Included tables: 8. Scientific baselines: 1. Original production tables: 8.

Read docs/USAGE_KO.md. The primary is a reference-assisted pressure-primary outer + SPG_M1–SLy4 smooth barotrope. Other included tables are declared construction sensitivities.

Install NumPy and SciPy, then run `python evaluate.py --list` or `python evaluate.py --pressure 0 0.0001 1`. No native executable is needed for evaluation.

REPRESENTATION.json and its consumer provide exact P=0. The CoMPOSE export contains only positive densities. Use the recorded piecewise laws and one-sided CSS interface choice. High-density extrapolation is rejected; upper density is 0.5 fm^-3.

The 17 public outer isotope tabulation gaps are explicitly effective regularizations. The package does not contain TOV or oscillation results.

SHA256SUMS.txt and MANIFEST.json cover every member except those two self-describing files. Native execution commands retain their historical paths as provenance; portable evaluation uses only relative paths. Full regeneration still requires the original repository.
