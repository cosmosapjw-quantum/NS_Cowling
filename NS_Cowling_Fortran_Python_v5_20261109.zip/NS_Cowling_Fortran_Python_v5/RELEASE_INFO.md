# Release provenance

- Package: compact NS_Cowling Fortran + Python source distribution
- Source archive supplied: `NS_Cowling_SOURCE_v5.tar.gz`
- Source snapshot date recorded in the archive: 2026-11-09
- Scope: runtime Fortran sources, Python frontends, frontend tests, focused technical notes
- Excluded: 234-EOS cohort, large data tables, historical generator, raw EOS libraries, course notes, cached executables, experiment logs
- Python package metadata preserved from source snapshot (`compose-cowling-pipeline` 2.0.0)
- No Git commit SHA is asserted for the uploaded source archive.
- No `LICENSE` file was present in the source snapshot; no new licence grant is implied.
