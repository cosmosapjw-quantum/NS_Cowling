# Change and Repair Report — Core–Crust EOS Package v3.2.0

**Source revision:** 65f943e4ffbb20af03d47  
**Upgrade date:** 2026-11-06  
**Mutation policy:** source archive preserved; upgraded artifacts created under new names.

## 1. Scope

This report records code, data, workflow and documentation changes. The separate Adversarial Audit Report contains the finding-by-finding scientific rationale and numerical verdict.

## 2. Source-data repair

### 2.1 CompOSE composition normalization

The original raw provider tables remain under eos_data/. A separate eos_data_normalized/ directory was created. The normalizer does not apply a blanket Y_I/A conversion to raw files. It reconstructs the nuclear-group baryon fraction Y_h only after checking:
$$
Y_n+Y_p+Y_h=1,\qquad
Y_p+(\bar Z/\bar A)Y_h=Y_e+Y_\mu.
$$
For rows where the supplied free-neutron/proton fractions cannot satisfy the two constraints, the missing fraction is reconstructed under the charge-neutrality and baryon-closure constraints. The normalized CompOSE value is then Y_I=Y_h/Abar.

The manifest records, model by model, source and normalized eos.compo hashes, row counts, inferred row adjustments, and maximum closure residuals. The raw tables are untouched. This is an explicit reconstruction of inconsistent source composition, not a claim that every provider's microscopic abundances are uniquely recoverable. A portable `scripts/normalize_compose_composition.py` now reproduces the normalization into a new directory; unresolved tables are omitted whole and the failure is recorded. GM_GM1 is omitted because its source charge closure fails at row 49.

### 2.2 Grid-index repairs

The eos.t index header was corrected for RG_KDE0v1 and RG_SLY4 to agree with the actual iT index in eos.thermo. No temperature or thermodynamic data values were changed.

## 3. Matching implementation

- Removed fixed APR/BBB core-start array index 69; core selection is derived from the table's composition phase information or density threshold.
- Removed undocumented +4.96005 MeV GM1 and +2.45 MeV FSU2 energy offsets. Default gauge alignment is now the neutron-mass reference difference only.
- Replaced clipped endpoint c_s^2 secants with one-sided PCHIP derivatives in log(n_b). Invalid/noncausal endpoints reject the candidate instead of being clipped.
- Reclassified the transition-window secant condition as a candidate-screening heuristic, not a theorem sufficient to prove convexity.
- Changed core composition default to strict_thermo_only. A core composition is propagated only if its baryon and charge closure both pass.
- Restricted the optional parabolic symmetry-energy beta-equilibrium approximation to registered APR/BBB core models. It is opt-in and not described as an exact microscopic composition calculation.
- Replaced “exact Maxwell/first-order” metadata with a smooth near-pressure-plateau construction label. All bridge methods have no density jump in this implementation; Seidov diagnostics are marked not applicable.
- Added core composition acceptance/rejection provenance to matching metadata.

## 4. TOV and target-mass implementation

- Central pressures are checked against the tabulated EOS range; no silent clipping or extrapolation is performed.
- Each of the three integration stages must hit its own pressure event. Missing events and failed integrator status now raise.
- The solver validates positive monotone P(epsilon) data and uses a smooth log-P/log-epsilon PCHIP barotrope.
- The target-mass solver brackets the stable branch in log central pressure and uses a scalar root solver. Radius, Love number, Lambda and crust thickness are evaluated at the root itself.
- The TOV helper explicitly supports smooth barotropes. Tidal matching across a genuine first-order density jump is not yet implemented.

One representative root was independently executed for SPG_M1 + BBB_BHF2, quintic_P, target 1.4 solar masses: M=1.399999999821 solar masses, Pc=109.225792714 MeV fm^-3, R=11.20793 km, k2=0.0684681 and Lambda=213.8125. The mass residual was 1.79e-10 solar masses.

## 5. Reader, writer and CLI

- The reader accepts legal six-field empty eos.compo rows. If every row has zero pairs and zero nuclear groups, it preserves phase IDs but marks physical composition unavailable.
- The writer no longer copies source eos.mr, eos.pdf, eos.init or README sidecars into a modified EOS.
- The writer retains transactional staging/rollback and standard CompOSE Y_I=Y_h/Abar output.
- The CLI defaults to strict thermo-only core composition and refuses hard-gate failures unless --allow-failed is explicitly passed for diagnostic export.
- Package version was advanced to 3.2.0.

## 6. Reproducible sweep runner

The 390-way runner now defaults to eos_data_normalized/ rather than the missing download/reconstructed_eos path. It writes actual gate states, bridge construction metadata and source file hashes. A failed EOS can be retained only with --allow-failed and is tagged diagnostic_only. The runner no longer calls linearized observables “exact target-mass results”. TOV target-mass solving is opt-in and calls the root solver.

The v3.2 run regenerated 390 tables: 234 PASS, 156 C10 causality FAIL, zero construction rejections. The 156 failed outputs are diagnostic only.

## 7. Tests and verification

- Original package tests before repair: 31 passed, 5 failed due hard-coded non-existent test input paths.
- v3.2 regression suite: 44 passed, 1 environment warning from the Matplotlib 3D projection import.
- compileall for maintained package code, scripts and tests: passed.
- Actual 1.4 solar-mass target root executed and checked against 1e-6 solar-mass tolerance.
- All 390 matching outputs were written without stale model-specific sidecars.

## 8. Remaining work (not claimed as complete)

- Re-run exact TOV roots for all 390 matched EOS only when requested; this release provides one representative real root validation.
- Implement a genuine Maxwell/Gibbs phase-transition EOS with a density jump and corresponding tidal perturbation jump conditions if that is a future scientific target.
- Replace the heuristic transition-window selector with a fully derived constrained convexity construction and convergence/uncertainty analysis.
- Benchmark the optional APR/BBB composition approximations against complete microscopic particle tables before using them in scientific inference.

## 9. Release contents

- upgraded matching/reader/writer/TOV package v3.2.0;
- unchanged raw EOS inputs and separate eos_data_normalized/ source tree;
- regenerated 390 matched EOS outputs and per-EOS metadata;
- matching summary CSV/JSON;
- normalization and verification manifests;
- separate adversarial audit report and this change report.
