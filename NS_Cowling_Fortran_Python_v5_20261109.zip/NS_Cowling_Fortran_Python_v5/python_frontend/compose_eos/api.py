"""Public Python API backed by the native Fortran EOS reader/writer/verifier."""
from __future__ import annotations
import json
import math
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any
from .eos_data import EOSData
from .native import run_native, NativeFeatureUnavailable, NativeExecutionError

def read_compose(directory: str | Path) -> EOSData:
    """Read a cold 1-D CompOSE slice with the Fortran reader."""
    source = Path(directory).expanduser().resolve()
    with tempfile.TemporaryDirectory(prefix="compose-eos-read-") as td:
        target = Path(td) / "internal"
        target.mkdir()
        run_native("read", source, target)
        return EOSData.from_internal_directory(target, source_dir=str(source))

def _resolve_nadd(data: EOSData, copy_from: str | Path | None) -> int:
    """Resolve the optional CompOSE thermo-column count without guessing semantics."""
    import numpy as np
    raw = data.q_extra_count
    if raw is not None:
        try:
            nadd = int(raw)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("q_extra_count must be 0 or 1") from exc
        if isinstance(raw, bool) or nadd != raw:
            raise ValueError("q_extra_count must be an integer 0 or 1")
    elif copy_from is not None:
        thermo = Path(copy_from).expanduser() / "eos.thermo"
        if not thermo.is_file():
            raise FileNotFoundError(f"copy_from does not contain eos.thermo: {thermo}")
        rows = [line.split() for line in thermo.read_text(encoding="utf-8").splitlines()
                if line.strip() and not line.lstrip().startswith("#")]
        if len(rows) < 2:
            raise ValueError("copy_from eos.thermo has no data rows")
        counts: set[int] = set()
        for index, fields in enumerate(rows[1:], start=2):
            if len(fields) < 11:
                raise ValueError(f"copy_from eos.thermo:{index}: short row")
            try:
                count = int(fields[10])
            except ValueError as exc:
                raise ValueError(f"copy_from eos.thermo:{index}: invalid Nadd") from exc
            if count < 0 or len(fields) != 11 + count:
                raise ValueError(f"copy_from eos.thermo:{index}: Nadd does not match extra columns")
            counts.add(count)
        if len(counts) != 1:
            raise ValueError("copy_from eos.thermo changes Nadd within one table")
        nadd = counts.pop()
    else:
        extra = getattr(data, "q_extra", None)
        nadd = int(extra is not None and np.asarray(extra).shape == (data.n,)
                   and np.any(np.asarray(extra, dtype=float) != 0.0))
    if nadd not in (0, 1):
        raise NativeFeatureUnavailable("the native CompOSE writer supports Nadd=0 or 1")
    return nadd


def _validate_compose_output(data: EOSData, *, composition_tolerance: float,
                             copy_from: str | Path | None) -> int:
    """Validate the complete output contract before invoking the native writer."""
    import numpy as np

    if not isinstance(data, EOSData):
        raise TypeError("data must be an EOSData instance")
    n = data.n
    if n < 3:
        raise ValueError("EOSData requires at least three density points")
    if not math.isfinite(composition_tolerance) or composition_tolerance < 0.0:
        raise ValueError("composition_tolerance must be finite and non-negative")
    for name in ("nb", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "q_extra",
                 "Iphase", "Yn", "Yp", "Ye", "Ymu", "Aav", "Zav", "Yh"):
        arr = np.asarray(getattr(data, name))
        if arr.shape != (n,):
            raise ValueError(f"{name} must be a one-dimensional vector of length {n}")
        if not np.all(np.isfinite(arr)):
            raise ValueError(f"{name} contains non-finite values")
    if np.any(data.nb <= 0.0) or np.any(np.diff(data.nb) <= 0.0):
        raise ValueError("EOSData.nb must be positive and strictly increasing")
    if np.any(data.Q1 * data.nb <= 0.0):
        raise ValueError("CompOSE output pressure must be positive")
    if not math.isfinite(data.mn) or not math.isfinite(data.mp) or data.mn <= 0.0 or data.mp <= 0.0:
        raise ValueError("nucleon masses must be finite and positive")
    try:
        il_value = int(data.Il)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("CompOSE Il must be the integer 0 or 1") from exc
    if isinstance(data.Il, bool) or il_value != data.Il or il_value not in (0, 1):
        raise ValueError("CompOSE Il must be the integer 0 or 1")
    if not math.isfinite(data.temperature_mev) or abs(float(data.temperature_mev)) > 1e-12:
        raise ValueError("the native CompOSE writer supports cold T=0 tables only")
    if np.any(data.Iphase != np.rint(data.Iphase)):
        raise ValueError("Iphase values must be integers")
    nadd = _resolve_nadd(data, copy_from)
    if nadd == 1 and not np.all(np.isfinite(data.q_extra)):
        raise ValueError("Nadd=1 requires finite q_extra values")

    if data.composition_available:
        for name in ("Yn", "Yp", "Ye", "Ymu", "Yh"):
            values = np.asarray(getattr(data, name), dtype=float)
            if np.any(values < -1e-10) or np.any(values > 1.0 + composition_tolerance):
                raise ValueError(f"composition fraction {name} must lie in [0,1]")
        if np.any(data.Aav < 0.0) or np.any(data.Zav < 0.0) or np.any(data.Zav > data.Aav + 1e-9):
            raise ValueError("invalid Abar/Zbar in nuclear group")
        has_group = data.Aav > 0.0
        if np.any(data.Aav[has_group] < 1.0):
            raise ValueError("a nuclear group requires Abar >= 1")
        if np.any((~has_group) & (data.Yh > 1e-10)):
            raise ValueError("Yh is nonzero although Abar indicates no nuclear group")
        y_i = np.divide(data.Yh, data.Aav, out=np.zeros(n, dtype=float), where=has_group)
        baryon_residual = data.Yn + data.Yp + data.Aav * y_i - 1.0
        charge_residual = data.Yp + data.Zav * y_i - data.Ye - data.Ymu
        max_baryon = float(np.max(np.abs(baryon_residual)))
        max_charge = float(np.max(np.abs(charge_residual)))
        if max_baryon > composition_tolerance or max_charge > composition_tolerance:
            raise ValueError(
                "composition does not satisfy CompOSE baryon/charge closure: "
                f"max baryon residual={max_baryon:.3e}, charge residual={max_charge:.3e}, "
                f"tolerance={composition_tolerance:.3e}"
            )
    elif n > 1 and np.any(np.asarray(data.Iphase)[1:] != np.asarray(data.Iphase)[:-1]):
        raise NativeFeatureUnavailable(
            "a phase-discontinuous barotrope without phase composition cannot be exported as a complete CompOSE table"
        )
    return nadd


def _commit_compose_files(stage: Path, target: Path, names: tuple[str, ...]) -> None:
    """Replace CompOSE payload files as one recoverable commit, preserving unrelated sidecars."""
    backup = stage.parent / "backup"
    backup.mkdir()
    managed = (*names, "eos.compo")
    existed = {name: (target / name).is_file() for name in managed}
    for name, present in existed.items():
        if present:
            shutil.copy2(target / name, backup / name)
    changed: list[str] = []
    try:
        for name in names:
            os.replace(stage / name, target / name)
            changed.append(name)
        if "eos.compo" not in names and existed["eos.compo"]:
            (target / "eos.compo").unlink()
            changed.append("eos.compo")
    except Exception:
        for name in reversed(changed):
            if existed[name]:
                os.replace(backup / name, target / name)
            else:
                (target / name).unlink(missing_ok=True)
        raise


def write_compose(directory: str | Path, data: EOSData, copy_from: str | Path | None = None, *,
                  composition_tolerance: float = 2e-3) -> None:
    """Write a validated cold CompOSE table through a staged native transaction.

    ``copy_from`` is consulted only when ``data.q_extra_count`` is ``None``;
    model-specific sidecars are never copied. Existing output files are restored
    if committing the staged EOS fails.
    """
    import numpy as np

    nadd = _validate_compose_output(
        data, composition_tolerance=float(composition_tolerance), copy_from=copy_from
    )
    to_write = data.copy()
    to_write.q_extra_count = nadd
    to_write.composition_file_present = bool(to_write.composition_available)
    target = Path(directory).expanduser().resolve()
    if target.exists() and not target.is_dir():
        raise NotADirectoryError(target)
    target.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="compose-eos-write-", dir=target.parent) as td:
        stage_root = Path(td)
        internal = stage_root / "internal"
        stage = stage_root / "output"
        stage.mkdir()
        to_write.write_internal_directory(
            internal, composition_tolerance=float(composition_tolerance)
        )
        run_native("write", internal, stage)
        # Parse the staged result before mutating the user's destination.
        read_compose(stage)
        names = ("eos.nb", "eos.t", "eos.yq", "eos.thermo")
        if to_write.composition_available:
            names += ("eos.compo",)
        _commit_compose_files(stage, target, names)

def check_consistency(data: EOSData, verbose: bool = True, *,
                      algebraic_tolerance: float = 2e-6,
                      max_log_step_for_derivatives: float = 0.25,
                      cs2_tolerance: float = 1e-6,
                      composition_tolerance: float = 2e-5) -> dict[str, Any]:
    """Run native C1-C11 checks; C7-C9 are finite-difference diagnostics."""
    del verbose
    if (algebraic_tolerance != 2e-6 or max_log_step_for_derivatives != 0.25
        or cs2_tolerance != 1e-6 or composition_tolerance != 2e-5):
        raise NativeFeatureUnavailable("custom C1-C11 tolerances are not yet exposed by the Fortran CLI")
    with tempfile.TemporaryDirectory(prefix="compose-eos-verify-") as td:
        directory = Path(td) / "internal"
        data.write_internal_directory(directory)
        output = Path(td) / "report.json"
        run_native("verify-csv", directory, output)
        raw = json.loads(output.read_text(encoding="utf-8"))
    c1 = {"temperature_mev": data.temperature_mev, "maxQ2": raw["C1_max_Q2"],
          "maxQ6mQ7": raw["C1_max_Q6_minus_Q7"], "maxmul": raw["C1_max_mu_l"],
          "pass_": raw["C1"]["pass"]}
    c2 = {"applicable": raw["C2"]["applicable"], "max_rel": raw["C2_max_relative_residual"],
          "pass_": raw["C2"]["pass"], "basis": "Fortran CompOSE thermodynamic closure"}
    def composition_check(name: str):
        key = "C3_max_absolute_residual" if name == "C3" else "C4_max_absolute_residual"
        item = raw[name]
        return {"status": item["status"], "max_abs": raw[key], "pass_": item.get("pass")}
    c5 = {"maxmul": raw["C1_max_mu_l"], "applicable": raw["C5"]["applicable"],
          "pass_": raw["C5"].get("pass")}
    c6 = {"min_dPdnb": raw["min_dP_dnb"], "min_delta_p": raw["min_delta_P"],
          "pass_": raw["C6"]["pass"]}
    def diagnostic(name: str):
        return {"max_rel": raw[name]["max_rel"], "n_points": raw[name]["n_points"],
                "status": "FINITE_DIFFERENCE_DIAGNOSTIC"}
    c10 = {"min_cs2": raw["min_cs2"], "max_cs2": raw["max_cs2"],
        "min_cs2_first_law": raw["min_cs2_first_law"], "max_cs2_first_law": raw["max_cs2_first_law"],
        "acausal_point_count": raw["acausal_point_count"],
        "acausal_point_count_first_law": raw["acausal_point_count_first_law"],
        "n_points": raw["derivative_points"], "pass_": raw["C10"]["pass"]}
    c11 = {"min_dmubdnb": raw["min_dmu_b_dnb"], "n_points": raw["derivative_points"],
           "pass_": raw["C11"]["pass"]}
    return {"C1":c1,"C2":c2,"C3":composition_check("C3"),"C4":composition_check("C4"),
        "C5":c5,"C6":c6,"C7":diagnostic("C7"),"C8":diagnostic("C8"),"C9":diagnostic("C9"),
        "C10":c10,"C11":c11,
        "overall":{"status":raw["overall"]["status"],"pass_":raw["overall"]["pass"],
            "failed_checks":[x for x in raw["failed_checks"].split(",") if x],
            "finite_primary_arrays":True,
            "note":"C7-C9 are diagnostics; the native hard gate is C1-C6/C10/C11."},
        "native_report":raw}

def normalize_compose(directory: str | Path, output_csv: str | Path) -> Path:
    output=Path(output_csv).expanduser().resolve();output.parent.mkdir(parents=True,exist_ok=True)
    run_native("normalize",Path(directory).expanduser().resolve(),output)
    return output

def find_density_gap(data: EOSData, min_ratio: float = 5.0) -> int:
    """Return the zero-based lower-row index of the largest native density gap."""
    import math
    if not isinstance(data, EOSData):
        raise TypeError("data must be an EOSData instance")
    threshold = float(min_ratio)
    if not math.isfinite(threshold) or threshold <= 1.0:
        raise ValueError("min_ratio must be finite and exceed one")
    with tempfile.TemporaryDirectory(prefix="compose-eos-detect-gap-") as td:
        source = Path(td) / "source"
        source.mkdir()
        data.write_internal_directory(source)
        try:
            payload = run_native("detect-gap", source, format(threshold, ".17g"))
        except NativeExecutionError as exc:
            if "no density gap found" in str(exc):
                raise ValueError(str(exc)) from exc
            raise
    return int(payload["gap_index"])


def causality_profile(data: EOSData, *, n_min: float = 0.0,
                      max_log_step: float = 0.25, tolerance: float = 1e-6) -> dict[str, Any]:
    """Run the native three-scheme causality diagnostic profile.

    The result preserves the historic ``pchip``, ``cubic_spline`` and
    ``centered_fd`` summaries and the derivative-scheme classification.  It
    is a diagnostic only: no source EOS values are clipped or changed.
    """
    import math
    if not isinstance(data, EOSData):
        raise TypeError("data must be an EOSData instance")
    n_min_value = float(n_min)
    max_step_value = float(max_log_step)
    tolerance_value = float(tolerance)
    if not math.isfinite(n_min_value):
        raise ValueError("n_min must be finite")
    if not math.isfinite(max_step_value) or max_step_value <= 0.0:
        raise ValueError("max_log_step must be finite and positive")
    if not math.isfinite(tolerance_value) or tolerance_value < 0.0:
        raise ValueError("tolerance must be finite and non-negative")
    with tempfile.TemporaryDirectory(prefix="compose-eos-causality-profile-") as td:
        source = Path(td) / "source"
        source.mkdir()
        data.write_internal_directory(source)
        payload = run_native(
            "causality-profile", source,
            format(n_min_value, ".17g"),
            format(max_step_value, ".17g"),
            format(tolerance_value, ".17g"),
        )
    return {
        "pchip": payload["pchip"],
        "cubic_spline": payload["cubic_spline"],
        "centered_fd": payload["centered_fd"],
        "classification": payload["classification"],
        "native_report": payload,
    }

def fill_density_gap(data: EOSData, n_fill: int = 60, fit_points: int = 12, *,
                     gap_phase: int | None = None) -> EOSData:
    """Fill the largest density gap with a native First-Law master-function bridge.

    Source knots outside the gap are copied unchanged.  The inserted segment is
    built from F(ln n_B), with Q1=dF/dln(n_B), mu_B=F+Q1 and Q7=Q6.
    No legacy-Python numerical fallback is used.
    """
    if not isinstance(n_fill, int) or isinstance(n_fill, bool) or n_fill < 1:
        raise ValueError("n_fill must be >= 1")
    if not isinstance(fit_points, int) or isinstance(fit_points, bool) or fit_points < 2:
        raise ValueError("fit_points must be >= 2")
    igap = find_density_gap(data, min_ratio=5.0)
    if data.composition_available and data.Iphase[igap] != data.Iphase[igap + 1] and gap_phase is None:
        raise ValueError(
            f"density gap crosses phase IDs {int(data.Iphase[igap])}->{int(data.Iphase[igap + 1])}; "
            "pass gap_phase explicitly instead of silently assigning a phase"
        )
    with tempfile.TemporaryDirectory(prefix="compose-eos-fill-gap-") as td:
        root = Path(td)
        source = root / "source"
        target = root / "filled"
        source.mkdir()
        target.mkdir()
        data.write_internal_directory(source)
        command = ["fill-gap", source, target, str(n_fill), str(fit_points)]
        if gap_phase is not None:
            command.append(str(int(gap_phase)))
        run_native(*command)
        return EOSData.from_internal_directory(target, source_dir=data.source_dir)


def causal_completion(data: EOSData, *, cs2: float = 1.0,
                      n_max: float | None = None, n_points: int = 200,
                      return_metadata: bool = False):
    """Append a native constant-sound-speed tail at the first resolved cs2=1 crossing.

    This creates an explicit high-density model alternative, not a unique repair
    of the microscopic source EOS. The output intentionally omits composition.
    Set return_metadata=True to receive (EOSData, native_report).
    """
    import math
    if not isinstance(data, EOSData):
        raise TypeError("data must be an EOSData instance")
    if not isinstance(n_points, int) or isinstance(n_points, bool) or n_points < 4:
        raise ValueError("n_points must be an integer >= 4")
    sound_speed = float(cs2)
    if not math.isfinite(sound_speed) or not (0.0 < sound_speed <= 1.0):
        raise ValueError("cs2 must be finite and in (0, 1]")
    if n_max is None:
        n_max_arg = 0.0
    else:
        n_max_arg = float(n_max)
        if not math.isfinite(n_max_arg) or n_max_arg <= 0.0:
            raise ValueError("n_max must be finite and positive when specified")

    with tempfile.TemporaryDirectory(prefix="compose-eos-causal-completion-") as td:
        root = Path(td)
        source = root / "source"
        target = root / "completed"
        source.mkdir()
        target.mkdir()
        data.write_internal_directory(source)
        payload = run_native(
            "causal-complete", source, target,
            format(sound_speed, ".17g"), format(n_max_arg, ".17g"), str(n_points)
        )
        completed = EOSData.from_internal_directory(target, source_dir=data.source_dir)
    if return_metadata:
        return completed, payload
    return completed


def construct_maxwell_transition(phase_low: EOSData, phase_high: EOSData, *,
                                  assume_local_charge_neutrality: bool = False,
                                  return_report: bool = False):
    """Construct a genuine single-conserved-charge Maxwell transition natively.

    Inputs are two cold, beta-equilibrated, composition-free single-phase
    barotropes. All thermodynamic interpolation, stability and causality checks
    are performed by the Fortran backend. The Python layer only serializes the
    input/output tables and exposes the native report.
    """
    if not isinstance(phase_low, EOSData) or not isinstance(phase_high, EOSData):
        raise TypeError("phase_low and phase_high must both be EOSData instances")
    if not isinstance(assume_local_charge_neutrality, bool):
        raise TypeError("assume_local_charge_neutrality must be bool")
    if not assume_local_charge_neutrality:
        raise ValueError(
            "confirm that both input phases are locally charge neutral by passing "
            "assume_local_charge_neutrality=True; the thermo-only data cannot prove this from composition"
        )
    with tempfile.TemporaryDirectory(prefix="compose-eos-maxwell-") as td:
        root = Path(td)
        low_dir, high_dir, target_dir = root / "low", root / "high", root / "maxwell"
        low_dir.mkdir()
        high_dir.mkdir()
        target_dir.mkdir()
        phase_low.write_internal_directory(low_dir)
        phase_high.write_internal_directory(high_dir)
        payload = run_native("maxwell-transition", low_dir, high_dir, target_dir, "true")
        matched = EOSData.from_internal_directory(target_dir, source_dir=phase_low.source_dir)
    consistency = check_consistency(matched)
    if not consistency["overall"]["pass_"]:
        failed = ", ".join(consistency["overall"]["failed_checks"])
        raise NativeExecutionError(
            "Fortran Maxwell output failed the independent C1-C6/C10-C11 verifier: " + failed
        )
    report = dict(payload)
    report["construction"] = "single_conserved_charge_local_neutrality_maxwell"
    report["local_charge_neutrality"] = "caller_confirmed"
    report["composition_preserved"] = False
    report["compose_export_allowed"] = False
    report["consistency"] = consistency
    report["is_exact_maxwell"] = True
    report["seidov_criterion_evaluated"] = False
    report["tov_interface_support"] = "not_verified"
    return (matched, report) if return_report else matched


def reconstruct_master(data: EOSData, smooth: bool = True,
                       smooth_sigma: float = 0.05,
                       fix_dissolution: bool = True,
                       dissolution_tol: float = 0.015, *,
                       recompute_extra_cs2: bool = False,
                       return_report: bool = False):
    """Reconstruct a cold beta-equilibrated EOS from its free-energy master function.

    The numerical transformation is performed by the native Fortran backend.
    Smoothing is a local weighted-cubic regularisation in log(n_B), not a
    compatibility claim for SciPy's global UnivariateSpline. If composition
    is available, the backend enforces baryon/charge conservation and solves
    electron-muon Fermi-gas equilibrium. Composition-free tables retain their
    supplied Q4 and composition placeholders.
    """
    import math
    if not isinstance(data, EOSData):
        raise TypeError("data must be an EOSData instance")
    if not isinstance(smooth, bool) or not isinstance(fix_dissolution, bool):
        raise TypeError("smooth and fix_dissolution must be bool")
    if not isinstance(recompute_extra_cs2, bool):
        raise TypeError("recompute_extra_cs2 must be bool")
    sigma = float(smooth_sigma)
    tolerance = float(dissolution_tol)
    if not math.isfinite(sigma) or (smooth and not (0.0 < sigma <= 0.5)):
        raise ValueError("smooth_sigma must be finite and lie in (0, 0.5] when smooth=True")
    if not math.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError("dissolution_tol must be finite and non-negative")
    if data.n < 5:
        raise ValueError("reconstruct_master requires at least five source points")
    with tempfile.TemporaryDirectory(prefix="compose-eos-reconstruct-master-") as td:
        root = Path(td)
        source, target = root / "source", root / "rebuilt"
        source.mkdir()
        target.mkdir()
        data.write_internal_directory(source)
        payload = run_native(
            "reconstruct-master", source, target,
            "true" if smooth else "false", format(sigma, ".17g"),
            "true" if fix_dissolution else "false", format(tolerance, ".17g"),
            "true" if recompute_extra_cs2 else "false",
        )
        rebuilt = EOSData.from_internal_directory(target, source_dir=data.source_dir)
    consistency = check_consistency(rebuilt)
    if not consistency["overall"]["pass_"]:
        failed = ", ".join(consistency["overall"]["failed_checks"])
        raise NativeExecutionError(
            "native reconstructed EOS failed independent C1-C6/C10-C11 checks: " + failed
        )
    report = dict(payload)
    report["master_function"] = "F(log(n_B))"
    report["interpolation"] = "local_weighted_cubic_then_PCHIP" if smooth else "PCHIP_of_source_F"
    report["first_law_closure"] = "Q1=dF/dln(n_B); mu_B=F+Q1; P=n_B Q1; epsilon=n_B F"
    report["composition_provenance"] = (
        "reconstructed_beta_equilibrium" if data.composition_available
        else "source_composition_absent_and_not_invented"
    )
    report["composition_preserved"] = bool(data.composition_available)
    report["q_extra_recomputed_as_cs2"] = recompute_extra_cs2
    report["consistency"] = consistency
    return (rebuilt, report) if return_report else rebuilt


def match_crust_core(d_cr: EOSData | None = None, d_co: EOSData | None = None,
                    cr_name: str = "", co_name: str = "",
                    method: str = "quintic_P", n_bridge: int = 40, *,
                    core_compo_mode: str = "strict_thermo_only",
                    drop_composition: bool = False):
    """Join cold crust/core barotropes with the native six-method Fortran bridge.

    The native v1 implementation is deliberately strict-thermo-only. Any input
    carrying an eos.compo file or usable composition requires the caller to opt
    in to dropping that information with drop_composition=True.
    """
    import math
    if d_cr is None or d_co is None:
        raise NativeFeatureUnavailable(
            "match_crust_core requires both crust and core EOSData inputs; "
            "the native smooth thermo-only matching API is available when both are supplied."
        )
    if not isinstance(d_cr, EOSData) or not isinstance(d_co, EOSData):
        raise TypeError("d_cr and d_co must both be EOSData instances")
    methods = {"maxwell", "css", "cubic_F", "cubic_P", "quintic_F", "quintic_P"}
    if method not in methods:
        raise ValueError(f"method must be one of {sorted(methods)}")
    if not isinstance(n_bridge, int) or isinstance(n_bridge, bool) or n_bridge < 8:
        raise ValueError("n_bridge must be an integer >= 8")
    if core_compo_mode != "strict_thermo_only":
        raise NativeFeatureUnavailable(
            "The native matcher currently supports only core_compo_mode='strict_thermo_only'; "
            "literature_beta_eq reconstruction is not ported."
        )
    if not isinstance(drop_composition, bool):
        raise TypeError("drop_composition must be bool")
    crust_has_composition = bool(d_cr.composition_file_present or d_cr.composition_available)
    core_has_composition = bool(d_co.composition_file_present or d_co.composition_available)
    carries_composition = crust_has_composition or core_has_composition
    if carries_composition and not drop_composition:
        raise ValueError(
            "one or both EOS inputs carry composition data; pass drop_composition=True "
            "to explicitly discard it in the matched output"
        )
    if not math.isfinite(float(d_cr.temperature_mev)) or not math.isfinite(float(d_co.temperature_mev)):
        raise ValueError("input temperatures must be finite")
    if abs(float(d_cr.temperature_mev)) > 1e-12 or abs(float(d_co.temperature_mev)) > 1e-12:
        raise ValueError("native matching requires T=0 inputs")
    if not d_cr.beta_equilibrated or not d_co.beta_equilibrated:
        raise ValueError("native matching requires beta-equilibrated inputs")
    for label, data in (("crust", d_cr), ("core", d_co)):
        if not all(len(getattr(data, name)) == data.n for name in
                   ("Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Iphase")):
            raise ValueError(f"{label} EOS arrays have inconsistent lengths")
        if not all(math.isfinite(float(v)) for v in data.nb):
            raise ValueError(f"{label} density grid contains nonfinite values")

    with tempfile.TemporaryDirectory(prefix="compose-eos-match-core-") as td:
        root = Path(td)
        crust_dir, core_dir, target_dir = root / "crust", root / "core", root / "matched"
        crust_dir.mkdir()
        core_dir.mkdir()
        target_dir.mkdir()
        d_cr.write_internal_directory(crust_dir)
        d_co.write_internal_directory(core_dir)
        payload = run_native(
            "match-core", crust_dir, core_dir, target_dir, method, str(n_bridge),
            "true" if drop_composition else "false",
        )
        matched = EOSData.from_internal_directory(target_dir, source_dir=d_cr.source_dir)

    # Preserve the legacy tuple return while adding the complete native report
    # and an independently generated C1-C11 consistency record.
    consistency = check_consistency(matched)
    dm_crust = float(d_co.mn - d_cr.mn)
    f1, f2 = float(payload["F1"]), float(payload["F2"])
    p1, p2 = float(payload["P1"]), float(payload["P2"])
    mu1, mu2 = float(payload["mu1"]), float(payload["mu2"])
    info = {
        "crust": cr_name, "core": co_name, "method": method,
        "i1": int(payload["i1"]), "i2": int(payload["i2"]), "n_bridge": n_bridge,
        "n1": float(payload["n1"]), "n2": float(payload["n2"]),
        "dnb": float(payload["n2"] - payload["n1"]),
        "P1": p1, "P2": p2, "dP": p2 - p1,
        "mu1": mu1, "mu2": mu2, "dmu": mu2 - mu1,
        "eps1": float(payload["n1"] * f1), "eps2": float(payload["n2"] * f2),
        "deps": float(payload["n2"] * f2 - payload["n1"] * f1),
        "seidov_ratio": None, "seidov_applicable": False,
        "is_exact_maxwell": False, "density_jump_fm3": 0.0,
        "phase_transition_order": None,
        "phase_transition_class": "not_assigned_no_density_jump",
        "construction_kind": payload["construction_kind"],
        "regularity_class": payload["construction_kind"],
        "cs2_1": float(payload["cs2_source_left"]),
        "cs2_2": float(payload["cs2_source_right"]),
        "cs2_left_br": float(payload["cs2_left"]),
        "cs2_right_br": float(payload["cs2_right"]),
        "dcs2_left": abs(float(payload["cs2_left"]) - float(payload["cs2_source_left"])),
        "dcs2_right": abs(float(payload["cs2_right"]) - float(payload["cs2_source_right"])),
        "cs2_min_bridge": float(payload["cs2_min"]),
        "cs2_max_bridge": float(payload["cs2_max"]),
        "first_law_relative_residual": float(payload["first_law_relative_residual"]),
        "pressure_span_bridge": float(payload["pressure_span"]),
        "spline_mode": payload["spline_mode"],
        "dm_crust": dm_crust, "dm_core": 0.0,
        "core_compo_mode": core_compo_mode,
        "composition_provenance": "none_strict_thermo_only",
        "core_composition_input_status": "explicitly_dropped" if core_has_composition else "input_eos_compo_absent",
        "core_composition_input_usable": False,
        "composition_dropped": bool(payload["composition_dropped"]),
        "diagnostic_only": not bool(consistency["overall"]["pass_"]),
        "consistency": consistency,
        "native_report": payload,
    }
    return matched, info
