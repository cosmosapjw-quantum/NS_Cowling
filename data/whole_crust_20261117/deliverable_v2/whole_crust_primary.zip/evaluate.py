#!/usr/bin/env python3
"""Evaluate the included piecewise EOS; NumPy and SciPy are required."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"code/python_frontend"))
from compose_eos.whole_crust import WholeCrustBarotrope
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("--list",action="store_true")
p.add_argument("--model",help="model ID from CATALOG.json; default is the primary baseline")
p.add_argument("--pressure",type=float,nargs="+",help="pressure(s) in MeV fm^-3, including zero")
p.add_argument("--transition-side",choices=("low","high"),default="high")
p.add_argument("--output",type=Path,help="new JSON file; existing files are never overwritten")
a=p.parse_args()
catalog=json.loads((ROOT/"CATALOG.json").read_text())
if a.list:
 print(json.dumps(catalog,indent=2));sys.exit(0)
if a.pressure is None:p.error("provide --pressure or --list")
selected=a.model or catalog["primary_model_id"]
byid={m["id"]:m for m in catalog["models"]}
if selected not in byid:p.error("model is not included in this bundle")
record=byid[selected]
contract=json.loads((ROOT/record["representation_path"]).read_text())
eos=WholeCrustBarotrope.from_contract(contract)
try:values=eos.state_at_pressure(a.pressure,transition_side=a.transition_side)
except ValueError as exc:p.error(str(exc))
result={"model":selected,"family":record["family"],"transition_side":a.transition_side,
 "units":{"n":"fm^-3","p":"MeV fm^-3","epsilon":"MeV fm^-3","mu":"MeV",
          "cs2_over_c2":"dimensionless","enthalpy":"dimensionless"},
 "states":[{k:float(values[k][i]) for k in values} for i in range(len(a.pressure))],
 "physical_support_n_fm3":record["physical_support_n_fm3"],
 "consumer_source":str(Path(sys.modules["compose_eos.whole_crust"].__file__).resolve())}
text=json.dumps(result,indent=2,allow_nan=False)+"\n"
if a.output:
 with a.output.open("x") as f:f.write(text)
else:print(text,end="")
