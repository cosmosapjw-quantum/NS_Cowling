# Technical Reference — compose_eos v3.2.0

## 1. Units and cold barotropic thermodynamics

The package handles a cold, one-dimensional CompOSE slice. The input density is n_b in fm^-3; pressure P, free-energy density f and internal-energy density epsilon are in MeV fm^-3; baryon chemical potential is in MeV. CompOSE tables use natural units for the underlying EOS data.

For a zero-temperature barotrope, define free energy per baryon F_b=f/n_b. The thermodynamic relations are
$$
P=n_b^2\frac{dF_b}{dn_b},\qquad
\mu_b=F_b+\frac{P}{n_b},\qquad
\epsilon=n_bF_b.
$$
Consequently,
$$
\frac{d\epsilon}{dn_b}=\mu_b,\qquad
c_s^2=\frac{dP}{d\epsilon}
=\frac{dP/dn_b}{d\epsilon/dn_b}
=\frac{1}{\mu_b}\frac{dP}{dn_b}.
$$
Mechanical stability requires dP/dn_b >= 0 and dmu_b/dn_b >= 0 on a smooth branch. Relativistic causality requires 0 <= c_s^2 <= 1. The reported derivative checks are finite-grid diagnostics; passing them is not a mathematical proof between every pair of knots.

## 2. CompOSE composition semantics

A CompOSE nuclear-group quadruple contains group ID, average mass number Abar, average charge number Zbar, and group number abundance Y_I. The number abundance is not the baryon fraction:
$$
Y_I=n_I/n_b,\qquad Y_h=\bar A Y_I.
$$
The writer emits Y_I=Y_h/Abar. Baryon and charge closure are
$$
Y_n+Y_p+Y_h=1,\qquad
Y_p+(\bar Z/\bar A)Y_h=Y_e+Y_\mu.
$$
Rows with no pairs and no quadruple are valid syntax but do not constitute available particle composition.

## 3. Source normalization policy

The original provider inputs are preserved under eos_data/. Because some raw nuclear-group fields vary in meaning across model/phase tables, the normalizer never applies one blind conversion to all raw rows. It first tests the input n/p fractions against both closure equations. If a missing free fraction must be inferred, the reconstruction is constrained by charge neutrality and baryon closure. It records the adjustment and both file hashes in COMPOSITION_NORMALIZATION_MANIFEST.json. The separate eos_data_normalized/ tree is the supported input for the v3.2 sweep. Inferred abundances remain reconstructed quantities, not source-measured truth.

## 3A. Reproducing the normalized composition tree

The portable normalizer is `scripts/normalize_compose_composition.py`. Run it against the untouched raw inputs and select a new destination:

```bash
python3 scripts/normalize_compose_composition.py --input-root eos_data --output-root ./eos_data_normalized_rebuilt
```

Unresolved composition tables are omitted as a whole from the normalized copy and recorded in the manifest; they are never partially rewritten. GM_GM1 is omitted because its original composition fails charge closure. The raw provider table remains unchanged.

## 4. Matching representations

The six method tokens are:
- maxwell: legacy compatibility token for a smooth near-pressure-plateau bridge; not an exact Maxwell construction;
- css: piecewise constant-sound-speed-style smooth barotropic bridge;
- cubic_F: cubic interpolation in F_b versus log(n_b);
- cubic_P: cubic interpolation in P versus mu_b;
- quintic_F: quintic/C2 interpolation in F_b versus log(n_b);
- quintic_P: quintic/C2 interpolation in P versus mu_b.

All current methods return a smooth, single-valued barotrope with zero density jump. They do not encode a first-order coexistence jump or latent heat. Consequently, no transition order or Seidov criterion is assigned. The names cubic/quintic refer to interpolation regularity, not phase-transition order.

## 5. Rest-mass gauge alignment

The crust/core source tables can use different neutron-mass reference values. The default matching gauge shift is
$$
\Delta m_n=m_{n,\mathrm{core}}-m_{n,\mathrm{crust}}.
$$
It shifts the crust energy-per-baryon/free-energy reference consistently while leaving pressure and its derivatives invariant. The prior hard-coded GM1/FSU2 offsets were removed because their source provenance was not established. A user-supplied, source-justified offset would need an explicit, versioned parameter with evidence.

## 6. Transition-window selection and bridge validation

The secant-slope condition
$$
n_1 < \frac{P_2-P_1}{\mu_2-\mu_1} < n_2
$$
is a candidate-screening heuristic. It is not a sufficient theorem that the full constructed EOS is convex, mechanically stable or causal. Endpoint sound speeds are estimated from one-sided PCHIP derivatives in log(n_b), without clipping. An endpoint outside 0<c_s^2<1 is rejected. The completed table must then pass the independent Euler, monotonicity, composition, stability and causality checks.

## 7. Composition policy at the junction

Default: strict_thermo_only. An input core composition is included only if C3 charge closure and C4 baryon closure both pass over the core input. A core table with a syntactically present but inconsistent eos.compo is treated as composition unavailable. The matched table omits eos.compo if the whole core composition cannot be validated.

Optional: literature_beta_eq. This opt-in path uses a parabolic symmetry-energy approximation for registered APR and BBB core models only. It is an approximate composition closure, not a complete microscopic species reconstruction. Unsupported core models raise rather than borrowing another model's symmetry-energy fit.

## 8. TOV scope and target-mass roots

The matching module TOV solver requires finite, positive, strictly increasing pressure and energy-density arrays. The central pressure must lie within the input range and satisfy the matching-stage ordering. Each stage must reach its requested pressure event. A missed event or failed integration is an error, not a star result.

The target-mass routine searches the stable branch in log(P_c), brackets M(P_c)-M_target=0 and applies a scalar root solver. R, k2, Lambda and crust thickness are evaluated at that root. If the requested mass cannot be bracketed before the stable branch ends or the table upper bound is reached, the routine reports failure.

The present TOV module supports smooth single-valued barotropes only. A true first-order transition with a finite density jump needs an explicit tidal perturbation jump condition; this feature is not implemented in v3.2.

## 9. Hard-gate interpretation

The 390-combination sweep records each full-table consistency status. A FAIL remains a FAIL even if a lower-density causal subdomain could be used for a restricted application. The v3.2 regenerated matrix has 234 full-table PASS and 156 C10 causality FAIL (78 APR_APR, 78 RG_KDE0v1), with zero construction rejections. Failed outputs are retained only under --allow-failed and are tagged diagnostic_only=true.

## 10. Reproduction

Install:
\`\`\`bash
python3 -m pip install -e ./compose_eos_pkg
\`\`\`

Test:
\`\`\`bash
PYTHONPATH=compose_eos_pkg python3 -m pytest -q
PYTHONPATH=compose_eos_pkg python3 -m compileall -q compose_eos_pkg/compose_eos scripts tests
\`\`\`

Regenerate all 390 candidate tables (failed tables retained as diagnostics):
\`\`\`bash
PYTHONPATH=compose_eos_pkg python3 scripts/run_all_390_matching_experiments.py \\
  --eos-root eos_data_normalized --output ./matched_eos_v3_2 --allow-failed
\`\`\`

Optional exact TOV target-mass roots can be requested with --tov-target-mass 1.4. This adds a root solve for every constructed combination and can be expensive. It is not part of the default 390-table sweep.
