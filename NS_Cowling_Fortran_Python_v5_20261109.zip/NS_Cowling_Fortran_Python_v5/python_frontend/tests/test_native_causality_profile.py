from __future__ import annotations
import sys
from pathlib import Path

import numpy as np
import pytest
from scipy.interpolate import PchipInterpolator, CubicSpline

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_frontend"))

from compose_eos import EOSData, causality_profile


def profile_source(*, phase_edge=False):
    x = np.array([0.00, 0.06, 0.14, 0.25, 0.39, 0.52, 0.66, 0.82, 0.97])
    nb = np.exp(x)
    logp = 2.2 * x + 0.15 * x**2 - 0.04 * x**3
    loge = 1.05 * x + 0.04 * x**2 + 0.01 * x**3
    p = np.exp(logp)
    eps = np.exp(loge)
    mn = 939.0
    zeros = np.zeros_like(nb)
    phases = np.zeros(nb.size, dtype=int)
    if phase_edge:
        phases[5:] = 1
    return EOSData(
        nb=nb, mn=mn, mp=mn, Q1=p/nb, Q2=zeros.copy(),
        Q3=(eps+p)/(nb*mn)-1.0, Q4=zeros.copy(), Q5=zeros.copy(),
        Q6=eps/(nb*mn)-1.0, Q7=eps/(nb*mn)-1.0,
        q_extra=zeros.copy(), Iphase=phases,
        Yn=zeros.copy(), Yp=zeros.copy(), Ye=zeros.copy(), Ymu=zeros.copy(),
        Aav=zeros.copy(), Zav=zeros.copy(), Yh=zeros.copy(),
        composition_available=False,
    )


def legacy_profile(data, *, n_min=0.0, max_log_step=0.25, tolerance=1e-6):
    n = np.asarray(data.nb, float)
    p = np.asarray(data.p, float)
    e = np.asarray(data.eps, float)
    x = np.log(n)
    dln = np.diff(x)
    mask = np.ones(len(n), bool)
    mask[1:] &= dln <= max_log_step
    mask[:-1] &= dln <= max_log_step
    for i in np.where(np.diff(data.Iphase) != 0)[0]:
        mask[max(0, i-1):min(len(n), i+3)] = False
    mask &= n >= n_min
    result = {}
    for name in ("pchip", "cubic_spline", "centered_fd"):
        if name == "pchip":
            dp = PchipInterpolator(x, np.log(p)).derivative()(x)
            de = PchipInterpolator(x, np.log(e)).derivative()(x)
        elif name == "cubic_spline":
            dp = CubicSpline(x, np.log(p), bc_type="natural").derivative()(x)
            de = CubicSpline(x, np.log(e), bc_type="natural").derivative()(x)
        else:
            dp = np.gradient(np.log(p), x, edge_order=2)
            de = np.gradient(np.log(e), x, edge_order=2)
        cs = (p/e) * dp/de
        valid = mask & np.isfinite(cs) & (de > 0)
        ids = np.where(valid & (cs > 1+tolerance))[0]
        result[name] = {
            "max_cs2": float(np.max(cs[valid])) if np.any(valid) else None,
            "min_cs2": float(np.min(cs[valid])) if np.any(valid) else None,
            "acausal_count": int(ids.size),
            "acausal_nb_range": [float(n[ids[0]]), float(n[ids[-1]])] if ids.size else None,
            "first_acausal_nb": float(n[ids[0]]) if ids.size else None,
            "n_valid": int(valid.sum()),
            "acausal": bool(ids.size),
        }
    robust = all(result[k]["acausal"] for k in result)
    onset = [result[k]["first_acausal_nb"] for k in result if result[k]["first_acausal_nb"] is not None]
    result["classification"] = {
        "robust_acausality": robust,
        "onset_spread_fm3": float(max(onset)-min(onset)) if onset else 0.0,
        "root_cause": "source_EOS_acausality" if robust else (
            "derivative_scheme_sensitive" if onset else "no_acausality_detected"),
    }
    return result


def test_native_causality_profile_matches_legacy_three_derivative_schemes():
    source = profile_source(phase_edge=True)
    expected = legacy_profile(source, n_min=1.03, max_log_step=0.2, tolerance=2e-5)
    actual = causality_profile(source, n_min=1.03, max_log_step=0.2, tolerance=2e-5)
    for method in ("pchip", "cubic_spline", "centered_fd"):
        got, want = actual[method], expected[method]
        assert got["n_valid"] == want["n_valid"]
        assert got["acausal_count"] == want["acausal_count"]
        assert got["acausal"] is want["acausal"]
        for field in ("max_cs2", "min_cs2", "first_acausal_nb"):
            if want[field] is None:
                assert got[field] is None
            else:
                assert got[field] == pytest.approx(want[field], rel=2e-10, abs=2e-12)
        if want["acausal_nb_range"] is None:
            assert got["acausal_nb_range"] is None
        else:
            np.testing.assert_allclose(got["acausal_nb_range"], want["acausal_nb_range"], rtol=2e-10)
    assert actual["classification"]["root_cause"] == expected["classification"]["root_cause"]
    assert actual["classification"]["onset_spread_fm3"] == pytest.approx(
        expected["classification"]["onset_spread_fm3"], rel=2e-10, abs=2e-12)


def test_native_causality_profile_rejects_invalid_controls():
    source = profile_source()
    with pytest.raises(ValueError, match="max_log_step"):
        causality_profile(source, max_log_step=0.0)
    with pytest.raises(ValueError, match="tolerance"):
        causality_profile(source, tolerance=-1.0)


def test_native_causality_profile_reports_empty_mask_without_fabricating_extrema():
    source = profile_source(phase_edge=True)
    report = causality_profile(source, n_min=float(source.nb.max() * 2.0))
    for method in ("pchip", "cubic_spline", "centered_fd"):
        item = report[method]
        assert item["n_valid"] == 0
        assert item["max_cs2"] is None
        assert item["min_cs2"] is None
        assert item["first_acausal_nb"] is None
        assert item["acausal_nb_range"] is None
        assert item["acausal"] is False
    assert report["classification"] == {
        "robust_acausality": False,
        "onset_spread_fm3": 0.0,
        "root_cause": "no_acausality_detected",
    }


def test_native_causality_profile_rejects_nonmonotone_density():
    source = profile_source()
    source.nb[4] = source.nb[3]
    from compose_eos import NativeExecutionError
    with pytest.raises(NativeExecutionError, match="strictly increasing"):
        causality_profile(source)
