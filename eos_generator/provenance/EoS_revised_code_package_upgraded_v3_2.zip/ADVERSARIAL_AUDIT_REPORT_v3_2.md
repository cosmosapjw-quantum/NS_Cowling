# Adversarial Audit Report — Core–Crust EOS Package v3.2.0

**Audit date:** 2026-11-06  
**Source:** Dropbox /EoS_revised_code_package.zip  
**Source revision:** 65f943e4ffbb20af03d47  
**Source size:** 87,769,477 bytes  
**Source SHA-256:** f996f6b8059f6dbd05526029b3c2e65a77991ce738999fe9806ee2743971d8b2

The original ZIP was not modified. All repairs were performed in a separate staging tree.

## 1. Executive verdict

The source package contained useful and largely successful smooth core–crust interpolation machinery, but several of its strongest physical claims did not match the implemented algorithms. The most consequential issues were inconsistent legacy nuclear-group abundance conventions in the provider EOS files; unsupported empirical energy-zero offsets; a false “exact Maxwell / first-order transition” description for a smooth bridge; propagation of a core composition table that failed charge closure; stale source-model stellar sidecars copied into matched EOS directories; and a target-mass routine that forced the returned mass to the target by linearly interpolating stellar observables after only one local correction.

The upgraded v3.2 implementation corrects these behaviors and regenerates the 390 combinations from a separately normalized source tree. **All 390 candidate bridges were constructed and serialized. The independent full-table hard-gate classification is 234 PASS and 156 FAIL; all 156 failures are C10 causality failures, not parser or construction failures.** The failures comprise all 78 APR_APR combinations and all 78 RG_KDE0v1 combinations. Failed tables are retained only as explicitly tagged diagnostic outputs.

A genuine 1.4 solar-mass TOV target root was also solved for one representative matched EOS. The returned mass residual was 1.79e-10 solar masses. This validates the corrected root solver on one sample, not a 390-model TOV campaign.

## 2. Audit scope and evidence

The audit inspected the nested code package, all 18 source EOS directories, the 390-combination archive, the matching manual, the sweep script, and the existing tests. It then:

1. re-ran the supplied tests before modifying code;
2. parsed and profiled the original eos.compo data independently;
3. checked the CompOSE reference definition of nuclear-group abundance;
4. created a separate normalized EOS input tree while preserving the raw source tree;
5. corrected the parser, matching, composition policy, TOV solver, writer, CLI and sweep runner;
6. regenerated all 390 combinations;
7. independently checked the generated outputs and compared the hard-gate results;
8. tested the release test suite and package structure.

Native subagent execution was unavailable and was not simulated. The audit was performed serially with the connected Linux host, Python/SciPy and source literature checks.

## 3. Principal findings

| ID | Severity | Finding | Consequence |
|---|---|---|---|
| A-01 | BLOCKER | Raw eos.compo nuclear-group fields did not consistently use the official CompOSE number-abundance convention. | Naive interpretation could violate baryon conservation or charge neutrality. |
| A-02 | BLOCKER | GM_GM1 composition included nucleon fractions but failed charge closure because the corresponding lepton fractions were absent. | The composition was propagated into matched outputs despite failing the audit. |
| A-03 | BLOCKER | The method named maxwell was a smooth near-pressure plateau with nonzero pressure span. | It was incorrectly described as exact Maxwell coexistence with latent heat and a first-order density jump. |
| A-04 | BLOCKER | solve_star_at_target_mass used one Newton-like correction, then linearly interpolated radius, Love number, tidal deformability and crust thickness while returning the exact requested mass. | The reported target-mass star was not necessarily a TOV solution at that mass. |
| A-05 | HIGH | write_compose(copy_from=...) copied source eos.mr, eos.pdf, eos.init and README sidecars into modified EOS outputs. | The matched EOS could inherit crust-only mass–radius data and an incorrect source-model identity. |
| A-06 | HIGH | Endpoint c_s^2 values were clipped into prescribed intervals. | An unstable or acausal source endpoint could be made to look admissible rather than rejected. |
| A-07 | HIGH | Undocumented +4.96005 MeV (GM1 core) and +2.45 MeV (FSU2 crust) energy shifts were applied. | Matching outcomes depended on empirical constants without source-level provenance. |
| A-08 | HIGH | APR/BBB core-start selection used a fixed array index. | The selection depended on the particular density grid rather than the physical table. |
| A-09 | HIGH | Missing or unusable core composition could be treated as available based on file/array presence. | A syntactically present but physically inconsistent composition was propagated. |
| A-10 | HIGH | TOV integration clipped central pressures and did not require every stage to hit its requested pressure event. | Out-of-range or incomplete integrations could return apparently valid stellar values. |
| A-11 | MEDIUM | The 390-run script defaulted to an absent download/reconstructed_eos directory and described locally corrected TOV estimates as exact roots. | The full experiment was not reproducible as documented. |
| A-12 | MEDIUM | The parser rejected legal empty composition rows with Npairs=0 and Nquad=0. | Some valid CompOSE tables could not be read. |
| A-13 | MEDIUM | Two single-point temperature-grid headers did not match their thermo-row index. | Strict index-based readers rejected those tables. |

## 4. CompOSE composition convention and source normalization

The CompOSE Reference Manual v3.00 defines a nuclear-group abundance Y_I as a **number-density fraction**:
$$
Y_I=\sum_{j\in\mathcal M_I}Y_j=\frac{n_I}{n_b}.
$$
The group baryon fraction is Y_h=Abar_I Y_I. Therefore the standard CompOSE file representation is
$$
Y_I=\frac{Y_h}{Abar_I},
$$
not Y_h itself. See Sec. 4.2.3, Eqs. (4.20)–(4.22) of the [CompOSE Reference Manual v3.00](https://compose.obspm.fr/download/pdf/manual_v3.00.pdf).

The raw provider data in this package show phase-dependent convention drift. A blanket division of the raw field by Abar would therefore be unjustified. Instead, the separate eos_data_normalized/ tree reconstructs the group baryon fraction under the two independently checked constraints:
$$
Y_n+Y_p+Y_h=1,\qquad
Y_p+\frac{\bar Z}{\bar A}Y_h=Y_e+Y_\mu.
$$
Where the supplied Y_n,Y_p do not close both relations, the missing free-neutron or proton fraction is reconstructed from charge neutrality and the baryon sum, and the inferred adjustment is recorded. The normalized writer then stores Y_I=Y_h/Abar.

The raw eos_data/ tree is preserved unchanged. The normalized tree is a reconstructed input, not a claim that the provider's original particle fractions have been recovered uniquely. Its per-model before/after hashes, row counts and adjustment counts are recorded in eos_data_normalized/COMPOSITION_NORMALIZATION_MANIFEST.json.

Fifteen source models with composition data were normalized. The SPG models required 148–160 row-level neutron-fraction reconstructions; RG_SLY4 required one; the other composition tables passed closure without a reconstructed n/p entry. Two index headers (RG_KDE0v1/eos.t and RG_SLY4/eos.t) were also aligned to the actual iT=1 thermo-row index.

The reader now distinguishes a real composition table from a formally present eos.compo whose rows all contain zero particle pairs and zero nuclear groups.

## 5. Matching construction and physical interpretation

All six method tokens produce smooth, single-valued barotropes. The legacy maxwell token is retained for API compatibility, but the implementation uses an interior pressure variation of approximately 3% of the endpoint pressure difference. It has no exact equal-pressure coexistence construction, density jump, or latent heat. Consequently:
- is_exact_maxwell = false;
- density_jump_fm3 = 0;
- seidov_applicable = false;
- phase_transition_order = null.

The other tokens describe interpolation representations and regularity, not thermodynamic phase-transition orders. The secant-slope transition-window selector is now explicitly described as a screening heuristic, not a theorem sufficient to prove convexity or stability.

Endpoint sound speeds are computed from one-sided PCHIP derivatives of log(P) and log(epsilon) against log(n_b). Values outside 0<c_s^2<1 cause rejection; they are not clipped. Undocumented model-specific energy shifts were removed. The only default gauge alignment is the neutron-mass reference difference, Δm_n=m_n,core−m_n,crust, applied consistently to F_b and μ_b; it does not change pressure.

The matched EOS uses the thermodynamic construction:
$$
\frac{dF_b}{dn_b}=\frac{P}{n_b^2},\qquad
\mu_b=F_b+\frac{P}{n_b},\qquad
\epsilon=n_bF_b,
$$
so the zero-temperature first-law identity is dε/dn_b=μ_b. These identities are checked after serialization, not assumed merely from the interpolator type.

## 6. Regenerated 390-combination results

The v3.2 runner regenerated all 13 × 5 × 6 = 390 crust/core/method combinations from eos_data_normalized/.

| Core model | PASS | FAIL | Main reason |
|---|---:|---:|---|
| APR_APR | 0 | 78 | C10: superluminal smooth-branch c_s^2 in the full table |
| RG_KDE0v1 | 0 | 78 | C10: superluminal smooth-branch c_s^2 in the full table |
| BBB_BHF2 | 78 | 0 | — |
| GM_GM1 | 78 | 0 | Unusable input composition omitted; thermo EOS remains valid under tested hard gates |
| RG_SLY4 | 78 | 0 | — |
| **Total** | **234** | **156** | **0 construction rejections** |

All 156 failed outputs are diagnostic-only and are tagged diagnostic_only=true; they are not promoted to a physical EOS release. The regenerated output directories contain no copied source eos.mr, eos.pdf, eos.init or README sidecars.

## 7. TOV target-mass validation

The corrected solver uses a smooth monotone P(epsilon) relation, rejects out-of-range central pressures, and requires every integration stage to reach its requested pressure event. The target-mass routine brackets the stable branch in ln(P_c), uses a scalar root solver for M(P_c)-M_target, and evaluates all observables at the resulting central pressure. It does not interpolate R, k2, Lambda between two stars.

Representative validation: SPG_M1 crust + BBB_BHF2 core, quintic-P bridge, target 1.4 solar masses:
- P1=0.481250996 MeV fm^-3, P2=1.516686868 MeV fm^-3;
- solved Pc=109.225792714 MeV fm^-3;
- M=1.399999999821 solar masses, residual -1.79e-10 solar masses;
- R=11.20793 km, k2=0.0684681, Lambda=213.8125;
- finite-table crust thickness 1.21142 km.

This sample does not certify the TOV solution for all 390 combinations. The solver is for smooth barotropes; a genuine first-order density jump still requires the appropriate tidal perturbation matching condition and is not implemented here.

## 8. Verification performed

- Source package's original tests: 31 passed, 5 failed; the five failures were caused by hard-coded non-existent input paths in test helpers.
- Upgraded package tests: 44 passed; one environment warning reports Matplotlib's unavailable 3D projection (not used by EOS calculations).
- Maintained Python source, scripts and tests: compileall completed successfully.
- Matching sweep: 390 constructed / 0 rejected; full-table gate: 234 PASS / 156 FAIL.
- Sample target-mass TOV root: mass residual 1.79e-10 solar masses.
- Writer no longer copies stale source-model sidecars to matched outputs.
- Original source ZIP remains unchanged.

## 9. Remaining limitations

1. The source symmetry-energy fits used in the optional APR/BBB composition approximation are parabolic-model approximations, not a first-principles reconstruction of all species in the microscopic EOS. The option is disabled by default and unavailable for unregistered cores.
2. No exact Maxwell/Gibbs phase coexistence construction or finite-density-jump tidal matching is provided.
3. The secant-slope transition-window search is heuristic; the independent hard gates remain authoritative.
4. The TOV root validation is a representative integration, not a 390-model TOV campaign.
5. Full high-density causality failures in APR_APR and RG_KDE0v1 remain unresolved physical properties of those source tables, not repaired by interpolation.

## 10. References

- CompOSE Core Team, CompOSE Reference Manual, v3.00, Sec. 4.2.3, Eqs. (4.20)–(4.22): https://compose.obspm.fr/download/pdf/manual_v3.00.pdf
- S. Typel et al., CompOSE reference manual, Eur. Phys. J. A 58, 221 (2022), https://doi.org/10.1140/epja/s10050-021-00847-y
- M. Fortin et al., Neutron star radii and crusts: uncertainties and unified equations of state, Phys. Rev. C 94, 035804 (2016), https://doi.org/10.1103/PhysRevC.94.035804
- P. S. Ferreira and C. Providência, Unified neutron star equation of state and the crust-core transition, Universe 6, 220 (2020), https://doi.org/10.3390/universe6110220
- A. Akmal, V. R. Pandharipande and D. G. Ravenhall, The Equation of State of Nuclear Matter and Neutron Star Structure, Phys. Rev. C 58, 1804 (1998), https://doi.org/10.1103/PhysRevC.58.1804
