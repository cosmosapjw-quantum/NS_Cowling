# NS_Cowling: compact Fortran + Python distribution

**Source snapshot:** `NS_Cowling_SOURCE_v5.tar.gz` (2026-11-09)  
**Scientific backend:** GNU Fortran 2018  
**Python frontend:** `compose_eos` and `compose_cowling`

This archive is the compact, independently installable code distribution. It contains the native CompOSE/EOS engine, the TOV and relativistic Cowling solver sources, the Python APIs, their regression tests, and the implementation notes. It deliberately excludes the 234-EOS research cohort, raw EOS libraries, generated spectra, course material, audit artefacts, and prebuilt binaries. Supply your own EOS tables.

## 1. What is included

- `fortran_eos/`: native CompOSE reader/writer, C1-C11 thermodynamic checks, EOS operations, and the `compose_eos_fortran` CLI.
- `oscillation_source/support/src` and `oscillation_source/solutions/src`: the Fortran support, TOV, shooting, and Cowling kernels.
- `oscillation_source/solutions/app`: `case_driver` and `cell_solve` applications, compiled by the Python frontend on first use.
- `python_frontend/compose_eos`: CompOSE I/O, EOS validation, density-gap, causality, master-function, crust-core matching, and one-charge transition APIs.
- `python_frontend/compose_cowling`: EOS adapters and Python entry points for TOV sequences and Cowling spectra.
- `python_frontend/tests`: the frontend regression suite.
- `docs/`: focused implementation, feature-parity, EOS-method, and physics notes.

The archive's `compose-cowling` research-pipeline command is intentionally not installed: its subcommands depend on the full corpus, legacy generator, and 234-model release data, which are intentionally not shipped here. The `compose_cowling` Python API is included and independently usable.

## 2. Requirements

- Python 3.10 or newer.
- GNU Fortran (`gfortran`) with Fortran 2018 support.
- `bash` for the EOS build script. On Windows, use WSL2 or another POSIX-like environment with `gfortran`.
- Python dependencies are declared in `pyproject.toml`: NumPy and SciPy. Install the optional `test` extra to run tests.

The Fortran numerical backends are authoritative. There is no silent Python numerical fallback when a compiler or native executable is unavailable.

## 3. Install

Unpack the ZIP, enter its top-level directory, and run:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install '.[test]'
```

Check the CompOSE command:

```bash
compose-eos --help
compose-eos read /path/to/compose_directory
compose-eos verify /path/to/compose_directory --json verification.json
compose-eos normalize /path/to/compose_directory normalized_eos.csv
```

The first operation that needs the native EOS executable builds it with `gfortran` under `build/compose_eos_fortran/`. To build it explicitly:

```bash
bash fortran_eos/build.sh build/compose_eos_fortran
build/compose_eos_fortran --help
```

`compose-eos` supports the `read`, `verify`, and `normalize` subcommands. Other native operations are exposed through the Python API described below.

## 4. Python API: CompOSE and EOS operations

```python
from compose_eos import (
    read_compose,
    write_compose,
    check_consistency,
    find_density_gap,
    fill_density_gap,
    causality_profile,
    causal_completion,
    reconstruct_master,
    match_crust_core,
    construct_maxwell_transition,
)

eos = read_compose('/path/to/compose_directory')
report = check_consistency(eos)
print(report['overall'])

# Optional native operations; each returns a new EOS/report and does not
# silently invoke the historical Python implementation.
# gap_index = find_density_gap(eos, min_ratio=5.0)
# filled = fill_density_gap(eos, n_fill=60)
# profile = causality_profile(eos, n_min=0.0, max_log_step=0.25)

write_compose('/path/to/output_compose_directory', eos)
```

The writer validates array shape, finiteness, monotonic density/pressure, metadata, optional composition, baryon closure, and charge closure. It stages output, reads it back before commit, and rolls back failed replacements. A thermo-only overwrite removes an obsolete `eos.compo` sidecar; unrelated sidecars are preserved. `composition_tolerance` is applied by both Python preflight and the native writer. See `docs/FORTRAN_PYTHON_FRONTEND_V4.md` and the method-specific notes for exact preconditions.

## 5. Python API: TOV and Cowling

The `compose_cowling` API accepts either an `EOSData` object or a path to a normalized EOS CSV. When an `EOSData` object is supplied, the frontend writes and normalizes a temporary CompOSE table before invoking Fortran.

```python
from compose_eos import read_compose
from compose_cowling import (
    solve_tov_star,
    solve_tov_sequence,
    solve_cowling_spectrum,
)

eos = read_compose('/path/to/compose_directory')

# SI input: central pressure in Pa.
star = solve_tov_star(eos, pc_pa=1.5e34)
print(star)

# Each central pressure is an independent Fortran TOV solve.
sequence = solve_tov_sequence(eos, [1.0e34, 1.2e34, 1.5e34])

# Two brackets are required, ordered as [f-mode, p1-mode], in Hz.
spectrum = solve_cowling_spectrum(
    eos,
    pc_pa=1.4957e34,
    frequency_lo_hz=[2000.0, 5800.0],
    frequency_hi_hz=[3200.0, 8600.0],
)
print(spectrum)
```

`solve_tov_star` and `solve_cowling_spectrum` compile the Fortran `case_driver` and `cell_solve` executables on first use. The build is cached under `~/.cache/compose_eos_fortran/solver/` and keyed by the source contents. The solver uses the installed `oscillation_source` sources; it does not need the full research dataset.

All user-facing pressure arguments are SI pascals. Frequencies are Hz. The TOV/Cowling kernels return structured result dictionaries (including backend and diagnostics). The precise keys are defined by the Fortran result schema and are not frozen as a long-term external ABI.

## 6. Runtime source/executable selection

Two environment variables support a pinned runtime:

- `COMPOSE_EOS_FORTRAN_EXE=/absolute/path/to/compose_eos_fortran` selects an existing EOS executable and is checked first.
- `COMPOSE_EOS_FORTRAN_ROOT=/absolute/path/to/source/root` selects a source root containing `fortran_eos/build.sh` when the executable is not pinned.

For a standard installation, the package's `share/compose-eos` data directory is discovered automatically. An explicit executable override does not require a source checkout for EOS-only operations. TOV/Cowling compilation requires the bundled or explicitly selected source tree and `gfortran`.

## 7. Tests and verification

From the unpacked source directory:

```bash
python -m pip install '.[test]'
PYTHONPATH=python_frontend python -m pytest -q python_frontend/tests \
  -k 'not differential_corpus_18_eos and not combined_spectrum_234_modes_integrity and not native_smooth_matching_differential_against_legacy'
```

The compact archive intentionally omits the 18-EOS differential corpus, the 234-mode result CSV, and the historic Python EOS generator. Therefore the documented compact-package run reports **69 passed, 8 deselected**: two corpus/cohort integrity tests and six parameterized legacy-differential tests are not runnable from this archive. The full source workspace has a separate 77-test frontend result recorded in `docs/ADVERSARIAL_AUDIT_POST_RELEASE_20261109.md`; that result must not be attributed to this compact subset.

The native polynomial-extrema test is a separate Fortran executable:

```bash
bash fortran_eos/build.sh build/compose_eos_fortran
mkdir -p build/compose_eos_fortran/test

gfortran -std=f2018 -O2 -ffree-line-length-none -fimplicit-none -fcheck=all \
  -Ibuild/compose_eos_fortran/mod \
  fortran_eos/tests/test_polynomial_extrema.f90 \
  build/compose_eos_fortran/obj/compose_eos_types.o \
  build/compose_eos_fortran/obj/compose_eos_reconstruct.o \
  -o build/compose_eos_fortran/test/test_polynomial_extrema
build/compose_eos_fortran/test/test_polynomial_extrema
```

The full source-workspace 2026-11-09 post-release audit records the strict Fortran build, 77 frontend tests passed, separately bounded pipeline checks, and the native polynomial-extrema gate. The compact archive is intentionally smaller; its runnable subset and eight explicit deselections are stated below. The omitted corpus/cohort tests require research data not shipped here.

## 8. Scientific scope and non-claims

The stellar solver treats nonrotating, spherically symmetric, perfect-fluid backgrounds and the implemented polar-fluid relativistic Cowling sector. The paper cohort uses the stated quadrupolar sector, cold beta-equilibrated barotropic perturbation closure, and finite positive surface-pressure cutoff. It is not a full-GR metric-perturbation or quasi-normal-mode solver and does not calculate gravitational-wave damping. Rotation, magnetic stresses, elastic crust response, superfluid counter-motion, frozen-composition buoyancy, and sharp phase-interface transfer are outside the verified scope.

EOS method names must be interpreted literally from their documented contracts. In particular, the historical `maxwell` option in `match_crust_core` is a smooth near-pressure plateau compatibility construction with no density jump or latent heat. It is not a physical Maxwell coexistence construction. The separate `construct_maxwell_transition` API constructs a one-conserved-charge transition only under its explicit cold beta-equilibrated and local-charge-neutrality assumptions; it does not certify phase-interface stellar stability or mode transfer.

Full parity with the historic Python generator is not claimed. Global-spline candidate selection, composition-aware crust-core matching, `literature_beta_eq`, microscopic RMF/Skyrme/APR/quark solvers, Gibbs mixed-phase generation, and full phase-interface TOV/mode handling remain unported or outside the verified native path. See `docs/FORTRAN_EOS_FEATURE_PARITY.md` and individual implementation notes.

## 9. Source and provenance

The scientific source repository is [cosmosapjw-quantum/NS_Cowling](https://github.com/cosmosapjw-quantum/NS_Cowling). The full research release and its 234-EOS result corpus are separate from this compact code-only archive. The source archive label is not a Git commit identifier; use the repository's commit SHA and release manifests when citing a specific Git-tracked revision.

This source snapshot did not include a `LICENSE` file. The archive therefore does not add or imply a new redistribution licence; consult the repository owner before redistributing it.
