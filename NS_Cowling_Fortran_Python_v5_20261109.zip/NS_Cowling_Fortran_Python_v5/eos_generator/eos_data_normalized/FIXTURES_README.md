# Compact regression EOS fixtures

These three small normalized CompOSE tables are shipped only to make the
frontend regression tests self-contained. They are not a representative
EOS library, not the 234-model scientific cohort, and not a replacement for
user-supplied EOS input. The files are taken unchanged from the supplied
2026-11-09 source snapshot: `GPPVA_FSU2H`, `BBB_BHF2`, and `GM_GM1`.

The GPPVA table includes composition data; the other two provide thermo-only
barotropes for regression paths. PDF attachments and unrelated generator
outputs are intentionally omitted.
