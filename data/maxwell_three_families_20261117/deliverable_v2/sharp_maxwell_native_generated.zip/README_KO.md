# Sharp Maxwell EOS — 코드 생성 EOS끼리

이 archive는 `native_generated` 계열의 crust 13 × core 5 = 65개 조합을 포함한다.
출력이 있는 모델 쌍은 5개, 검증된 유한 구간 EOS 표는 6개다.
다른 계열끼리의 matching은 포함하지 않는다.

`matched_eos/`에는 실제 sharp Maxwell kernel, serialize/readback 및 admission을 통과한
**유한 구간 CompOSE EOS**만 들어 있다. 같은 모델 쌍에서 둘 이상의 독립 source component가
성공했다면 각각 별도 candidate다. 이를 유일한 전역적 평형 EOS나 완전한 중성자별 EOS로 간주하지 않는다.

`cells/`에는 성공·실패·지원 구간 부재를 포함한 65개 조합의 receipt와 모든 candidate RESULT가 있다.
실패한 candidate의 compose 파일은 matched_eos에 포함하지 않는다.
해가 없다는 결론은 실제로 계산한 admitted components에 한정된다.

`sources/`는 원본 전체 EOS, 준비된 입력, interval diagnostics, 재구성 receipt와 source provenance다.
공개 원본은 변경되지 않는다. reconstructed 계열의 원본 폴더는 그 재구성의 부모 자료이며,
공개 원본 계열과 교차 matching했다는 뜻이 아니다. 구성·auxiliary payload를 transport하지 않은
thermodynamic-only matching의 범위는 preparation receipt에 기록돼 있다.

`diagnostics/`의 source_retaining_thermo.csv는 원본 crust 앞부분, 검증된 matched 표,
원본 core 뒷부분을 물리 단위로 나란히 보존한 검토용 자료다. 재구성 계열은 명시적으로 재구성한
selected source rows에만 그 값을 적용한다. 이 CSV에는 보간·외삽·새 접합을 수행하지 않았고,
prefix/suffix 경계의 평형, 전체 인과성 또는 전체 EOS admission을 주장하지 않는다.
상태는 `DIAGNOSTIC_SOURCE_RETAINING_NOT_ADMITTED`다. accepted EOS의 별도 추가 개수로 세지 않는다.

단위는 n_B [fm^-3], P 및 epsilon [MeV fm^-3], mu [MeV]다.
각 source의 원래 CompOSE 질량 header로 물리량을 읽으며, 접합을 만들기 위한 에너지 기준 이동은 없다.
`ARCHIVE_MANIFEST.json`은 archive 안의 모든 payload member의 SHA256을 담는다.
