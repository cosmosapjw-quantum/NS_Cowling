# Core–crust CompOSE EOS package upgrade v3.2.0

## Contents

- `EoS_matching_code_package_v3_2.zip`: source code, raw EOS files, explicitly normalized EOS inputs, portable normalization script, tests, legacy snapshots and wheel.
- `matched_eos_all_combinations_v3_2.zip`: regenerated 390 matched EOS directories, per-EOS metadata and CSV/JSON summaries.
- `ADVERSARIAL_AUDIT_REPORT_v3_2.pdf/.md`: independent findings and numerical verdict.
- `CHANGE_AND_REPAIR_REPORT_v3_2.pdf/.md`: exact implementation/data/document changes.
- `TECHNICAL_REFERENCE_v3_2.pdf/.md`: equations, units, method semantics and reproduction instructions.
- `INDEPENDENT_READBACK_v3_2.json`, `COMPOSITION_NORMALIZATION_MANIFEST.json`, `TOV_TARGET_MASS_SAMPLE_v3_2.json`: inspectable verification evidence.

## Source identity

Audited Dropbox source: `EoS_revised_code_package.zip`; Dropbox revision `65f943e4ffbb20af03d47`; size 87,769,477 bytes; SHA-256 `f996f6b8059f6dbd05526029b3c2e65a77991ce738999fe9806ee2743971d8b2`. The source archive was not overwritten.

## Main results

- 390/390 matched output tables constructed and independently read back.
- 234 full-table hard-gate PASS; 156 C10 causality FAIL; zero construction rejections. All failures are APR_APR (78) and RG_KDE0v1 (78), retained as diagnostic-only.
- Independent readback: metadata mismatches 0; stale copied source sidecars 0.
- EOS consistency residual maxima: Euler relative `4.82e-16`, composition charge `1.0e-5`, baryon closure `3.54e-13`.
- Regression tests: 44 passed; source wheel built and installed separately as `compose-eos==3.2.0`.
- One representative 1.4 solar-mass TOV target root was solved with mass residual `1.79e-10 Msun`; this is not a 390-model TOV campaign.

## Important physical scope

All six bridge method tokens are smooth single-valued barotropes. The legacy `maxwell` token is not an exact Maxwell construction and has no density jump or latent heat. GM_GM1 source composition is omitted in the normalized input because charge closure fails; the raw source is preserved. APR and KDE0v1 remain acausal over part of their full source tables; failed results are not silently repaired.

## Reproduction

From the code package root:

```bash
python3 -m pip install -e ./compose_eos_pkg
PYTHONPATH=compose_eos_pkg python3 -m pytest -q
python3 scripts/normalize_compose_composition.py --input-root eos_data --output-root ./eos_data_normalized_rebuilt
PYTHONPATH=compose_eos_pkg python3 scripts/run_all_390_matching_experiments.py --eos-root eos_data_normalized --output ./matched_eos_v3_2 --allow-failed
```

See the technical reference for the meanings and limitations of each check.
