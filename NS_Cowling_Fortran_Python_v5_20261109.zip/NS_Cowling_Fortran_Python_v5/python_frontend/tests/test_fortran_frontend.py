import sys
from pathlib import Path
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_frontend"))

from compose_eos import read_compose, write_compose, check_consistency, NativeFeatureUnavailable
SAMPLE = ROOT / "eos_generator" / "eos_data_normalized" / "GPPVA_FSU2H"


def test_fortran_reader_verifier_and_roundtrip(tmp_path):
    eos = read_compose(SAMPLE)
    assert eos.n == 300
    assert eos.composition_available
    assert np.all(np.diff(eos.nb) > 0)
    assert np.array_equal(eos.p, eos.nb * eos.Q1)
    report = check_consistency(eos)
    assert report["overall"]["pass_"]
    out = tmp_path / "written"
    write_compose(out, eos)
    again = read_compose(out)
    for name in ("nb", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7",
                 "Yn", "Yp", "Ye", "Ymu", "Aav", "Zav", "Yh"):
        assert np.array_equal(getattr(eos, name), getattr(again, name)), name


def test_alternate_eos_roundtrip(tmp_path):
    source = ROOT / "eos_generator" / "eos_data_normalized" / "BBB_BHF2"
    eos = read_compose(source)
    path = tmp_path / "roundtrip"
    write_compose(path, eos)
    again = read_compose(path)
    assert np.array_equal(eos.Q1, again.Q1)
    assert np.array_equal(eos.nb, again.nb)
    assert again.composition_available == eos.composition_available
    for name in ("Q2","Q3","Q4","Q5","Q6","Q7"):
        assert np.array_equal(getattr(eos,name),getattr(again,name))


def test_native_density_gap_is_available_and_remaining_generator_operations_fail_explicitly():
    from compose_eos import fill_density_gap, reconstruct_master, match_crust_core, NativeExecutionError
    eos = read_compose(SAMPLE)
    filled = fill_density_gap(eos, n_fill=3, gap_phase=7)
    assert filled.n == eos.n + 3
    # Reconstruction is now implemented natively. This particular production
    # table is deliberately refused by the v1 interpolant's physical gate;
    # it must not fall back to the legacy Python smoother or emit an unchecked EOS.
    with pytest.raises(NativeExecutionError, match="master reconstruction .*failure"):
        reconstruct_master(eos)
    with pytest.raises(NativeFeatureUnavailable):
        match_crust_core(eos)


def test_normalize_compose_and_verify_csv(tmp_path):
    from compose_eos import normalize_compose
    norm = tmp_path / "normalized.csv"
    res = normalize_compose(SAMPLE, norm)
    assert res.is_file()
    assert res.stat().st_size > 0


def test_differential_corpus_18_eos():
    import json
    diff_file = ROOT / "fortran_eos" / "differential_corpus_v4" / "fortran_compose_differential.json"
    assert diff_file.is_file()
    data = json.loads(diff_file.read_text())
    assert data["n_tables"] == 18
    assert data["n_tested"] == 18
    assert data["n_failed"] == 0
    assert data["roundtrip_exact"] == 18
    assert len(data["tables"]) == 18


def test_tov_solver_star_integration():
    from compose_cowling.solver import solve_tov_star
    source = ROOT / "eos_generator" / "eos_data_normalized" / "BBB_BHF2"
    eos = read_compose(source)
    star = solve_tov_star(eos, pc_pa=1.5e34)
    assert star["status"] == "ok"
    assert star["backend"] == "Fortran"
    assert star["mass_nominal_solar"] > 1.0
    assert star["radius_m"] > 9000.0


def test_combined_spectrum_234_modes_integrity():
    import csv
    spec_file = ROOT / "combined_spectrum_records.csv"
    assert spec_file.is_file()
    with spec_file.open() as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 234
    assert len(set(r["name"] for r in rows)) == 234
    for r in rows:
        assert r["mode_status"] == "VALID"
        f_w = int(r["f_inner_W_nodes"]) + int(r["f_outer_W_nodes"])
        f_v = int(r["f_inner_V_nodes"]) + int(r["f_outer_V_nodes"])
        assert f_w == 0 and f_v == 0
        p1_w = int(r["p1_inner_W_nodes"]) + int(r["p1_outer_W_nodes"])
        p1_v = int(r["p1_inner_V_nodes"]) + int(r["p1_outer_V_nodes"])
        assert p1_w == 1 and p1_v == 1



def test_internal_metadata_parses_fortran_l1_logical_values(tmp_path):
    from compose_eos.eos_data import _read_metadata

    metadata = tmp_path / "eos_data.nml"
    metadata.write_text(
        "&metadata\n"
        " composition_file_present=F\n"
        " composition_available=F\n"
        " beta_equilibrated=T\n"
        "/\n",
        encoding="utf-8",
    )
    parsed = _read_metadata(metadata)
    assert parsed["composition_file_present"] is False
    assert parsed["composition_available"] is False
    assert parsed["beta_equilibrated"] is True


def test_writer_removes_stale_composition_file_on_thermo_only_overwrite(tmp_path):
    from compose_eos import read_compose

    with_composition = read_compose(SAMPLE)
    thermo_only = read_compose(ROOT / "eos_generator" / "eos_data_normalized" / "BBB_BHF2")
    output = tmp_path / "reused-output"
    write_compose(output, with_composition)
    assert (output / "eos.compo").is_file()

    write_compose(output, thermo_only)
    assert not (output / "eos.compo").exists()
    roundtrip = read_compose(output)
    assert not roundtrip.composition_available
    assert not roundtrip.composition_file_present


def test_writer_enforces_composition_closure_and_tolerance_before_mutation(tmp_path):
    eos = read_compose(SAMPLE)
    eos.Yn[0] += 0.1
    output = tmp_path / "invalid-output"
    with pytest.raises(ValueError, match="baryon/charge closure"):
        write_compose(output, eos, composition_tolerance=1e-12)
    assert not output.exists()


def test_writer_preserves_nadd_from_copy_from_when_metadata_is_unspecified(tmp_path):
    eos = read_compose(SAMPLE)
    assert eos.q_extra_count == 1
    expected = eos.q_extra.copy()
    eos.q_extra_count = None
    output = tmp_path / "copy-from-nadd"
    write_compose(output, eos, copy_from=SAMPLE)
    actual = read_compose(output)
    assert actual.q_extra_count == 1
    np.testing.assert_array_equal(actual.q_extra, expected)


def test_native_writer_removes_stale_composition_file_and_rejects_bad_closure(tmp_path):
    from compose_eos.native import run_native, NativeExecutionError

    thermo_only = read_compose(ROOT / "eos_generator" / "eos_data_normalized" / "BBB_BHF2")
    internal = tmp_path / "internal"
    thermo_only.write_internal_directory(internal)
    output = tmp_path / "native-output"
    output.mkdir()
    (output / "eos.compo").write_text("stale composition sidecar\n", encoding="utf-8")
    run_native("write", internal, output)
    assert not (output / "eos.compo").exists()

    bad = read_compose(SAMPLE)
    bad.Yn[0] += 0.1
    bad_internal = tmp_path / "bad-internal"
    bad.write_internal_directory(bad_internal)
    with pytest.raises(NativeExecutionError, match="baryon/charge closure"):
        run_native("write", bad_internal, tmp_path / "bad-output")


def test_native_root_environment_override_has_precedence(tmp_path, monkeypatch):
    from compose_eos.native import project_root

    requested = tmp_path / "selected-project"
    (requested / "fortran_eos").mkdir(parents=True)
    (requested / "fortran_eos" / "build.sh").write_text("#!/bin/sh\n", encoding="utf-8")
    monkeypatch.setenv("COMPOSE_EOS_FORTRAN_ROOT", str(requested))
    assert project_root() == requested.resolve()


def test_native_matching_construction_labels_are_not_truncated():
    from compose_eos import match_crust_core

    crust = read_compose(SAMPLE)
    core = read_compose(ROOT / "eos_generator" / "eos_data_normalized" / "GM_GM1")
    expected = {
        "maxwell": "smooth_near_pressure_plateau",
        "css": "two_segment_constant_sound_speed",
        "cubic_F": "cubic_free_energy_bridge",
        "quintic_F": "quintic_C2_free_energy_bridge",
        "cubic_P": "cubic_pressure_chemical_potential_bridge",
        "quintic_P": "quintic_C2_pressure_chemical_potential_bridge",
    }
    for method, label in expected.items():
        _, report = match_crust_core(
            crust, core, method=method, n_bridge=40,
            core_compo_mode="strict_thermo_only", drop_composition=True,
        )
        assert report["construction_kind"] == label


def test_writer_forwards_explicit_composition_tolerance_to_native_backend(tmp_path):
    eos = read_compose(SAMPLE)
    eos.Yn[0] += 1e-3
    output = tmp_path / "looser-tolerance-output"
    write_compose(output, eos, composition_tolerance=5e-3)
    roundtrip = read_compose(output)
    assert roundtrip.Yn[0] == pytest.approx(eos.Yn[0])


def test_explicit_native_executable_override_does_not_require_source_tree(tmp_path, monkeypatch):
    import compose_eos.native as native

    executable = tmp_path / "compose_eos_fortran"
    executable.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    monkeypatch.setenv("COMPOSE_EOS_FORTRAN_EXE", str(executable))
    monkeypatch.delenv("COMPOSE_EOS_FORTRAN_ROOT", raising=False)
    monkeypatch.setattr(native, "project_root", lambda: (_ for _ in ()).throw(
        native.NativeExecutionError("source tree must not be needed")
    ))
    assert native.executable() == executable.resolve()
