from __future__ import annotations

from compose_eos.native import project_root


def test_fortran_runtime_tree_is_complete() -> None:
    root = project_root()
    assert (root / "fortran_eos" / "build.sh").is_file()
    assert len(list((root / "fortran_eos" / "src").glob("*.f90"))) == 7
    assert len(list((root / "oscillation_source" / "support" / "src").glob("*.f90"))) == 18
    solver_sources = list((root / "oscillation_source" / "solutions" / "src").rglob("*.f90"))
    assert len(solver_sources) == 44
    required = (
        "diagnostics/ns_mode_diagnostics.f90",
        "eos/ns_table_eos.f90",
        "modes/ns_cowling.f90",
        "numerics/ns_adaptive_rk.f90",
        "structure/ns_tov.f90",
    )
    for relative in required:
        assert (root / "oscillation_source" / "solutions" / "src" / relative).is_file()
    assert (root / "oscillation_source" / "solutions" / "app" / "case_driver.f90").is_file()
    assert (root / "oscillation_source" / "solutions" / "app" / "cell_solve.f90").is_file()
